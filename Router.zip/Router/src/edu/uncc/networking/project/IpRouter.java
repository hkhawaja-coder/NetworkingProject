/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.uncc.networking.project;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 *
 * @author Dhyan Raj
 */
public class IpRouter {
        
        private Map<String, String> table;
        

        public IpRouter() {
        }
        
        
        public IpRouter(String[] table) {
                setTable(table);
        }
        
        
        public int route(String ip){
                int i = 0;
                for(String key : table.keySet()){
                        if(key.equals(and(ip, table.get(key)))){
                                return i;
                        }
                        i++;
                }
                
                return i;
        }
        
        private String and(String ip, String mask){
                ip = getAsBinary(ip);                
                
                StringBuilder sb = new StringBuilder();
                
                for(int i = 0; i < 32; i++){
                        sb.append(Integer.parseInt(ip.charAt(i) + "") & Integer.parseInt(mask.charAt(i) + ""));
                }
                
                return formatAsIp(sb.toString());
                
        }
        private String getSubnetMask(int subnet){                
                
                StringBuilder sb = new StringBuilder("00000000000000000000000000000000");
                for(int i = 0; i < subnet; i++){
                        sb.replace(i, i + 1, "1");
                }
                
                return sb.toString();
        }
        
        private String formatAsIp(String binary){
                StringBuilder sb = new StringBuilder();
                StringBuilder result = new StringBuilder();
                for(int i = 0; i < 32; i++){
                        
                        sb.append(binary.charAt(i));
                        if((i + 1) % 8 == 0){
                                result.append(Integer.parseInt(sb.toString(), 2));
                                result.append(".");
                                sb = new StringBuilder();
                        }
                }
                
                return result.substring(0, result.length() - 1);
        }
        private String getAsBinary(String ip){
                String[] parts = ip.split("\\.");
                StringBuilder sb = new StringBuilder();
                
                sb.append(getBinary(parts[0]));                
                sb.append(getBinary(parts[1]));
                sb.append(getBinary(parts[2]));
                sb.append(getBinary(parts[3]));
                
                return sb.toString();
                
        }
        
        private String getBinary(String part){
                return String.format("%8s", Integer.toBinaryString(Integer.parseInt(part))).replace(' ', '0');
        }

        public final void setTable(String[] table) {
                parseTable(table);
        }
        
        private void parseTable(String[] t){
                table = new LinkedHashMap<>();
                
                for(String row : t){
                        String[] cols = row.split("/");
                        table.put(cols[0], getSubnetMask(Integer.parseInt(cols[1])));
                }
        }
}
