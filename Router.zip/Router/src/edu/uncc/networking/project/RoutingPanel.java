package edu.uncc.networking.project;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.geom.Line2D;
import java.awt.image.BufferedImage;
import java.awt.image.RescaleOp;
import java.io.File;
import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.JPanel;

/**
 *
 * @author Dhyan Raj
 */
public class RoutingPanel extends JPanel {

	static Color blue = new Color(0, 0, 0);

	static Color green = new Color(255, 255, 255);

	static Color red = new Color(0, 0, 0);

	static long ADVANCE = 20;

	static long DELAY = 100;

	private Boolean sendData = false;

	private int sendReceiver = -1;

	int currentX;

	int currentY;

	int[] recX;

	int[] recY;

	int[] rec1X = { 66, 180, 180, 332, 332, 435 };

	int[] rec1Y = { 163, 163, 150, 150, 29, 29 };

	int[] rec2X = { 66, 180, 180, 350, 350, 435 };

	int[] rec2Y = { 163, 163, 155, 155, 120, 120 };

	int[] rec3X = { 66, 350, 350, 435 };

	int[] rec3Y = { 163, 163, 220, 220 };

	int[] rec4X = { 66, 180, 180, 332, 332, 435 };

	int[] rec4Y = { 163, 163, 165, 165, 320, 320 };

	int index = 0;

	Image router;

	Image sender;

	Image rec1;

	Image rec2;

	Image rec3;

	Image rec4;

	Image data;

	public RoutingPanel() {
		try {
			router = scaleImage(ImageIO.read(new File("router_logic.png")), 70);

			sender = scaleImage(ImageIO.read(new File("laptop.png")), 10);

			rec1 = scaleImage(ImageIO.read(new File("router_rec.jpg")), 6);

			rec2 = rec1;

			rec3 = scaleImage(ImageIO.read(new File("router.png")), 8);

			rec4 = rec3;

			data = scaleImage(ImageIO.read(new File("data.png")), 10);
		} catch (IOException ex) {
			Logger.getLogger(RoutingPanel.class.getName()).log(Level.SEVERE, null, ex);
		}
                
                initComponents();
	}

        private void initComponents() {

                jButton1 = new javax.swing.JButton();

                setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

                jButton1.setBackground(new java.awt.Color(255, 255, 255));
                jButton1.setText("jButton1");
                add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(39, 53, -1, -1));
        }

	@Override
	public void paint(Graphics g) {
                        super.paint(g);

		g.drawImage(sender, 10, 145, this);

		drawText("Interface 0", g, 365, 27);

		g.drawImage(rec1, 450, 2, this);

		drawText("Interface 1", g, 365, 117);

		g.drawImage(rec2, 450, 90, this);

		drawText("Router 1", g, 365, 217);

		g.drawImage(rec3, 470, 190, this);

		drawText("Router 2", g, 365, 317);

		drawText("Default", g, 365, 343);

		g.drawImage(rec4, 470, 290, this);

		if (sendReceiver < 0) {
			drawSenderToRouter(g, blue);
		} else {

			drawSenderToRouter(g, green);

		}

		switch (sendReceiver) {
			case 0:
				drawRouterToRec1(g, green);
                                drawTextForNewFunction("IP Matches With Interface 0", g, 600, 175);
				drawRouterToRec2(g, red);
				drawRouterToRec3(g, red);
				drawRouterToRec4(g, red);
				break;
			case 1:
				drawRouterToRec1(g, red);
				drawRouterToRec2(g, green);
                                drawTextForNewFunction("IP Matches With Interface 1", g, 600, 175);
				drawRouterToRec3(g, red);
				drawRouterToRec4(g, red);
				break;
			case 2:
				drawRouterToRec1(g, red);
				drawRouterToRec2(g, red);
				drawRouterToRec3(g, green);
                                drawTextForNewFunction("IP Matches With Router 1", g, 600, 175);
				drawRouterToRec4(g, red);
				break;
			case 3:
				drawRouterToRec1(g, red);
				drawRouterToRec2(g, red);
				drawRouterToRec3(g, red);
				drawRouterToRec4(g, green);
                                drawTextForNewFunction("IP did not match!", g, 600, 175);
                                drawTextForNewFunction("Sending to default Router", g, 600, 200);
				break;
			default:
				drawRouterToRec1(g, red);
				drawRouterToRec2(g, red);
				drawRouterToRec3(g, red);
				drawRouterToRec4(g, red);
		}
		sendToRec(g, data);

		drawTransparentImage(router, g, 160, 130);

	}

	private void drawText(String text, Graphics g, int x, int y) {
		Graphics2D g2d = (Graphics2D) g;

		RenderingHints rh = new RenderingHints(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

		rh.put(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);

		g2d.setRenderingHints(rh);

		g2d.setFont(new Font("Comic Sans MS", Font.PLAIN, 12));

		g2d.drawString(text, x, y);
	}
        private void drawTextForNewFunction(String text, Graphics g, int x, int y) {
		Graphics2D g2d = (Graphics2D) g;

		RenderingHints rh = new RenderingHints(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

		rh.put(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);

		g2d.setRenderingHints(rh);

		g2d.setFont(new Font("Comic Sans MS", Font.BOLD, 20));

		g2d.drawString(text, x, y);
	}

	private void drawSenderToRouter(Graphics g, Color color) {
		Color current = g.getColor();

		Graphics2D g2 = (Graphics2D) g;

		for (int i = 0; i < 2; i++) {
			if (i == 0) {
				g.setColor(color.darker());
				g2.setStroke(new BasicStroke(4));
			} else {
				g.setColor(color.brighter());
				g2.setStroke(new BasicStroke(2));
			}

			g2.draw(new Line2D.Float(66, 167, 160, 167));
		}

		g.setColor(current);

	}

	private void drawRouterToRec1(Graphics g, Color color) {
		Color current = g.getColor();

		Graphics2D g2 = (Graphics2D) g;

		for (int i = 0; i < 2; i++) {
			if (i == 0) {
				g.setColor(color.darker());
				g2.setStroke(new BasicStroke(4));
			} else {
				g.setColor(color.brighter());
				g2.setStroke(new BasicStroke(2));
			}

			g2.draw(new Line2D.Float(225, 155, 350, 155));
			g2.draw(new Line2D.Float(350, 155, 350, 35));
			g2.draw(new Line2D.Float(350, 35, 467, 35));

		}

		g.setColor(current);
                

	}

	private void drawRouterToRec2(Graphics g, Color color) {
		Color current = g.getColor();

		Graphics2D g2 = (Graphics2D) g;

		for (int i = 0; i < 2; i++) {
			if (i == 0) {
				g.setColor(color.darker());
				g2.setStroke(new BasicStroke(4));
			} else {
				g.setColor(color.brighter());
				g2.setStroke(new BasicStroke(2));
			}

			g2.draw(new Line2D.Float(225, 160, 360, 160));
			g2.draw(new Line2D.Float(360, 160, 360, 125));
			g2.draw(new Line2D.Float(360, 125, 467, 125));

		}

		g.setColor(current);

	}

	private void drawRouterToRec3(Graphics g, Color color) {
		Color current = g.getColor();

		Graphics2D g2 = (Graphics2D) g;

		for (int i = 0; i < 2; i++) {
			if (i == 0) {
				g.setColor(color.darker());
				g2.setStroke(new BasicStroke(4));
			} else {
				g.setColor(color.brighter());
				g2.setStroke(new BasicStroke(2));
			}

			g2.draw(new Line2D.Float(225, 165, 360, 165));
			g2.draw(new Line2D.Float(360, 165, 360, 225));
			g2.draw(new Line2D.Float(360, 225, 467, 225));

		}

		g.setColor(current);

	}

	private void drawRouterToRec4(Graphics g, Color color) {
		Color current = g.getColor();

		Graphics2D g2 = (Graphics2D) g;

		for (int i = 0; i < 2; i++) {
			if (i == 0) {
				g.setColor(color.darker());
				g2.setStroke(new BasicStroke(4));
			} else {
				g.setColor(color.brighter());
				g2.setStroke(new BasicStroke(2));
			}

			g2.draw(new Line2D.Float(225, 170, 350, 170));
			g2.draw(new Line2D.Float(350, 170, 350, 325));
			g2.draw(new Line2D.Float(350, 325, 467, 325));
		}

		g.setColor(current);

	}

	private void sendToRec(final Graphics g, final Image img) {
		if (null == recX) { return; }
		if (index < recX.length - 1) {
			if (currentX < recX[index + 1]) {
				currentX += ADVANCE;
				if (currentX > recX[index + 1]) {
					currentX = recX[index + 1];
				}
			} else if (currentY < recY[index + 1]) {
				currentY += ADVANCE;
				if (currentY > recY[index + 1]) {
					currentY = recY[index + 1];
				}
			} else if (currentY > recY[index + 1]) {
				currentY -= ADVANCE;
				if (currentY < recY[index + 1]) {
					currentY = recY[index + 1];
				}
			} else {
				index++;
			}
		} else {
			sendData = false;
		}
		g.drawImage(img, currentX, currentY, this);
	}

	private void drawTransparentImage(Image img, Graphics g, int x, int y) {
		int w = img.getWidth(null);
		int h = img.getHeight(null);
		BufferedImage bi = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
		Graphics g1 = bi.getGraphics();
		g1.drawImage(img, 0, 0, null);

		g1.dispose();

		float[] scales = { 1f, 1f, 1f, 0.91f };
		float[] offsets = new float[4];
		RescaleOp rop = new RescaleOp(scales, offsets, null);

		/* Draw the image, applying the filter */
		((Graphics2D) g).drawImage(bi, rop, x, y);
	}

	private Image scaleImage(Image img, int percentage) {

		return img.getScaledInstance(img.getWidth(this) * percentage / 100, img.getHeight(this) * percentage / 100,
		        Image.SCALE_SMOOTH);
	}

	public Boolean getSendData() {
		return sendData;
	}

	public void setSendData(Boolean sendData) {
		this.sendData = sendData;
	}

	public int getSendReceiver() {
		return sendReceiver;
	}

	public void setSendReceiver(int sendReceiver) {
		this.sendReceiver = sendReceiver;
		switch (sendReceiver) {
			case 0:
				recX = rec1X;
				recY = rec1Y;
				break;
			case 1:
				recX = rec2X;
				recY = rec2Y;
				break;
			case 2:
				recX = rec3X;
				recY = rec3Y;
				break;
			case 3:
				recX = rec4X;
				recY = rec4Y;
		}

		currentX = recX[0];
		currentY = recY[0];
		sendData = true;
		index = 0;

		TimerTask task = new TimerTask() {
			public void run() {

				synchronized (getSendData()) {
					if (getSendData()) {

						repaint();
					} else {
						cancel();
					}
				}
			}

		};
		Timer timer = new Timer();

		timer.schedule(task, 0, RoutingPanel.DELAY);
	}

        private javax.swing.JButton jButton1;
}
